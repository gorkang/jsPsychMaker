/* CSCN - Created with jsPsychMaker: https://github.com/gorkang/jsPsychMaker */


// Translations --------------------------------------------------------------
switch (language) {

  case "Spanish":

    CRTMCQ4_000 = ['<p><left><b><big>CRTMCQ4</big></b><br />'+
    'Verás algunas preguntas que varían en dificultad. Por favor, marca la alternativa que te parezca correcta.' +'</p>'];

    CRTMCQ4_001_prompt = '<div class="justified">Un bate y una pelota cuestan  $1.100 en total. El bate cuesta $1.000 más que la pelota ¿Cuánto cuesta la pelota? </div>';
    CRTMCQ4_001_options = ['&nbsp;50 pesos', '&nbsp;100 pesos', '&nbsp;90 pesos', '&nbsp;10 pesos']

    CRTMCQ4_002_prompt = '<div class="justified">Si 5 máquinas se demoran 5 minutos en hacer 5 audífonos ¿Cuánto tiempo se demorarían 100 máquinas en hacer 100 audífonos?</div>';
    CRTMCQ4_002_options = ['&nbsp;5 minutos', '&nbsp;100 minutos', '&nbsp;20 minutos', '&nbsp;500 minutos']


    CRTMCQ4_003_prompt = '<div class="justified">Parte de la superficie de un lago está cubierta con hojas de lirio. Esta parte, se dobla en tamaño cada día. Si las hojas de lirio demoran 48 días en cubrir el lago completo ¿Cuántos días tardarían en cubrir la mitad del lago?</div>'
    CRTMCQ4_003_options = ['&nbsp;47 días', '&nbsp;24 días', '&nbsp;12 días', '&nbsp;36 días'];

    CRTMCQ4_004_prompt = '<div class="justified">Si José puede tomar un barril de agua en 6 días y María puede tomar un barril de agua en 12 días ¿Cuánto se demorarían ambos en tomar un barril de agua juntos?</div>';
    CRTMCQ4_004_options = ['&nbsp;4 días', '&nbsp;9 días', '&nbsp;12 días', '&nbsp;3 días'];
    
    CRTMCQ4_005_prompt = '<div class="justified">Pedro recibió la quinceava nota más alta y la quinceava nota más baja en su clase ¿Cuántos estudiantes hay en su clase?</div>';
    CRTMCQ4_005_options = ['&nbsp;29 estudiantes', '&nbsp;30 estudiantes', '&nbsp;1 estudiante', '&nbsp;15 estudiantes'];
    
    CRTMCQ4_006_prompt = '<div class="justified">Un hombre compra un cerdo a $60.000, lo vende a $70.000, lo compra de nuevo por $80.000, y lo vuelve a vender finalmente por $90.000 ¿Cuánta plata ha ganado?</div>';
    CRTMCQ4_006_options = ['&nbsp;$20.000', '&nbsp;$10.000', '&nbsp;$0', '&nbsp;$30.000'];
    
    CRTMCQ4_007_prompt = '<div class="justified">Simón decide invertir $8.000.000 en el mercado de acciones un día a inicios de 2008. Seis meses después de haber invertido, el 17 de julio, las acciones que había comprado bajaron 50%. Afortunadamente para Simón, desde el 17 de julio hasta el 17 de octubre, las acciones que compró subieron 75%. En este punto, Simón:</div>';
    CRTMCQ4_007_options = ['&nbsp;ha ganado dinero.', '&nbsp;ha perdido dinero.', '&nbsp;no ha ganado ni perdido dinero.', '&nbsp;no se puede determinar.'];
    
    CRTMCQ4_008_prompt = '<div class="justified">¿Conocías los ítems anteriores?</div>';
    CRTMCQ4_008_options = ['&nbsp;Ninguno (0)', '&nbsp;Algunos (1 a 3)', '&nbsp;Bastantes (4 a 6)', '&nbsp;Todos (7)'];
  
    break;


  case "English":

    CRTMCQ4_000 = ['<p><left><b><big>CRTMCQ4</big></b><br />'+
     'You will see some questions that vary in difficulty. Please, mark the alternative that seems correct to you.' +'</p>'];

    CRTMCQ4_001_prompt = 'A bat and a ball cost $1.10 in total. The bat costs $1.00 more than the ball. How much does the ball cost?';
    CRTMCQ4_001_options = ['&nbsp;5 cents', '&nbsp;10 cents', '&nbsp;9 cents', '&nbsp;1 cent'];

    CRTMCQ4_002_prompt = 'If it takes 5 machines 5 minutes to make 5 widgets, how long would it take 100 machines to make 100 widgets?';
    CRTMCQ4_002_options = ['&nbsp;5 minutes', '&nbsp;100 minutes', '&nbsp;20 minutes', '&nbsp;500 minutes'];

    CRTMCQ4_003_prompt = 'In a lake, there is a patch of lily pads. Every day, the patch doubles in size. If it takes 48 days for the patch to cover the entire lake, how long would it take for the patch to cover half of the lake? ';
    CRTMCQ4_003_options = ['&nbsp;47 days', '&nbsp;24 days', '&nbsp;12 days', '&nbsp;36 days'];

    CRTMCQ4_004_prompt = 'If John can drink one barrel of water in 6 days, and Mary can drink one barrel of water in 12 days, how long would it take them to drink one barrel of water together?';
    CRTMCQ4_004_options = ['&nbsp;4 days', '&nbsp;9 days', '&nbsp;12 days', '&nbsp;3 days'];
    
    CRTMCQ4_005_prompt = 'Jerry received both the 15th highest and the 15th lowest mark in the class. How many students are in the class?';
    CRTMCQ4_005_options = ['&nbsp;29 students', '&nbsp;30 students', '&nbsp;1 student', '&nbsp;15 students'];
    
    CRTMCQ4_006_prompt = 'A man buys a pig for $60, sells it for $70, buys it back for $80, and sells it finally for $90. How much has he made? ';
    CRTMCQ4_006_options = ['&nbsp;$20', '&nbsp;$10', '&nbsp;$0', '&nbsp;$30'];
    
    CRTMCQ4_007_prompt = 'Simon decided to invest $8,000 in the stock market one day early in 2008.  Six months after he invested, on July 17, the stocks he had purchased were down 50%. Fortunately for Simon, from July 17 to October 17, the stocks he had purchased went up 75%. At this point, Simon:';
    CRTMCQ4_007_options = ['&nbsp;has lost money.', '&nbsp;is ahead of where he began.', '&nbsp;has broken even in the stock market.', '&nbsp;it cannot be determined.'];
    
    CRTMCQ4_008_prompt = '<div class="justified">Did you know the previous items?</div>';
    CRTMCQ4_008_options = ['&nbsp;None (0)', '&nbsp;Some (1 to 3)', '&nbsp;Quite a few (4 to 6)', '&nbsp;All (7)'];
  
    break;

}



// Task -----------------------------------------------------------------------

questions = ( typeof questions != 'undefined' && questions instanceof Array ) ? questions : [];
questions.push( check_fullscreen('CRTMCQ4') );

CRTMCQ4 = [];    //temporal timeline

var instruction_screen_experiment = {
    type: 'instructions',
    pages: CRTMCQ4_000,
    data: {trialid: 'CRTMCQ4_000', procedure: 'CRTMCQ4'},
    show_clickable_nav: true,
    on_trial_start: function(){
        bloquear_enter = 0;
    }
};

var question01 = {
  type: 'survey-multi-choice-vertical',
  questions: [{prompt: CRTMCQ4_001_prompt, 
  options: CRTMCQ4_001_options, random_options: true, required: true, horizontal: false}],
  data: {trialid: 'CRTMCQ4_001', procedure: 'CRTMCQ4'}
};
CRTMCQ4.push(question01);

var question02 = {
  type: 'survey-multi-choice-vertical',
  questions: [{prompt: CRTMCQ4_002_prompt, 
  options: CRTMCQ4_002_options, random_options: true, required: true, horizontal: false}],
  data: {trialid: 'CRTMCQ4_002', procedure: 'CRTMCQ4'}
};
CRTMCQ4.push(question02);

var question03 = {
  type: 'survey-multi-choice-vertical',
  questions: [{prompt: CRTMCQ4_003_prompt, 
  options: CRTMCQ4_003_options, random_options: true, required: true, horizontal: false}],
  data: {trialid: 'CRTMCQ4_003', procedure: 'CRTMCQ4'}
};
CRTMCQ4.push(question03);

var question04 = {
  type: 'survey-multi-choice-vertical',
  questions: [{prompt: CRTMCQ4_004_prompt, 
  options: CRTMCQ4_004_options, random_options: true, required: true, horizontal: false}],
  data: {trialid: 'CRTMCQ4_004', procedure: 'CRTMCQ4'}
};
CRTMCQ4.push(question04);

var question05 = {
  type: 'survey-multi-choice-vertical',
  questions: [{prompt: CRTMCQ4_005_prompt, 
  options: CRTMCQ4_005_options, random_options: true, required: true, horizontal: false}],
  data: {trialid: 'CRTMCQ4_005', procedure: 'CRTMCQ4'}
};
CRTMCQ4.push(question05);

var question06 = {
  type: 'survey-multi-choice-vertical',
  questions: [{prompt: CRTMCQ4_006_prompt, 
  options: CRTMCQ4_006_options, random_options: true, required: true, horizontal: false}],
  data: {trialid: 'CRTMCQ4_006', procedure: 'CRTMCQ4'}
};
CRTMCQ4.push(question06);

var question07 = {
  type: 'survey-multi-choice-vertical',
  questions: [{prompt: CRTMCQ4_007_prompt, 
  options: CRTMCQ4_007_options, random_options: true, required: true, horizontal: false}],
  data: {trialid: 'CRTMCQ4_007', procedure: 'CRTMCQ4'}
};
CRTMCQ4.push(question07);

var question08 = {
  type: 'survey-multi-choice-vertical',
  questions: [{prompt: CRTMCQ4_008_prompt, 
  options: CRTMCQ4_008_options, random_options: true, required: true, horizontal: false}],
  data: {trialid: 'CRTMCQ4_008', procedure: 'CRTMCQ4'}
};
CRTMCQ4.push(question08);

CRTMCQ4.unshift(instruction_screen_experiment);
questions.push.apply(questions, CRTMCQ4);
call_function("CRTMCQ4");
