// Configuration file

// Main parameters -------------------------------------------------------------
pid = 12; // Protocol ID [number]
online = true; // Protocol runs online [true/false]
max_participants = 999999; // Max participants per contition [number]
random_id = true; // Assign random id to participants [true/false]
max_time = "99:00:00"; // Max time to complete the protocol [HH:MM:SS]
accept_discarded = true; // If an user is discarded (out of time), should be allow her to continue? (given there are free slots) [true/false]
debug_mode = true; // SHOULD be false in production

var_researcher_email = `jmoraless@uc.cl`;


// INTRO [index.html] ----------------------------------------------------------
intro_HTML = '<div title="logo"><p style="margin-bottom: 0.2in; line-height: 100%"><img src="media/html/logo-UAI.png" name="UAI" align="bottom" width="200" height="55" border="0"/></p></div>' +
  'Bienvenido y gracias por participar de este estudio. <BR><BR>' +
  'Responder a esta encuesta le tomará 10 minutos aproximadamente. Por favor lea con atención cada pregunta. <BR><BR>' +
  '<B>IMPORTANTE</B>: Una vez que responda a una pregunta y pase a la siguiente <B>NO podrá volver atrás</B> para modificar su respuesta anterior. <BR><BR>';


// ORDER OF TASKS --------------------------------------------------------------

first_tasks = ['ConsentHTML', 'IDQ', 'AIM']; // First tasks (in sequential order)
last_tasks = ['Goodbye']; // Last tasks (in sequential order)

// Create as many as needed. The name should start with 'random_' when you want to randomize the order of tasks in the block
randomly_ordered_tasks_1 = ['DASS21', 'FDMQ', 'IRI', 'SRA']; // Block of tasks in random order
secuentially_ordered_tasks_1 = ['']; // Block of tasks in sequential order

// FINAL ARRAY of tasks [build combining the above blocks]
  // The order of the tasks in the arrays starting with "random" will be randomized
  // tasks SHOULD contain an array of strings. GOOD: tasks = ['my_tasks']; BAD: tasks = [my_tasks];
tasks = ['first_tasks', 'randomly_ordered_tasks_1', 'last_tasks'];




// MEDIA preloading ------------------------------------------------------------
message_str = 'El protocolo está cargando, espere un momento...'; // Message when preloading media

// media to preload in protocol_controller
images =  [];
audios = [];
video = [];


// BETWEEN participants variables ----------------------------------------------
all_conditions = {"protocol": {"type": ["survey"]}};
