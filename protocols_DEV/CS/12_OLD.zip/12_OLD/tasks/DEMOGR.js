/**
 * CSCN lab
/**
This document was made with test_maker
*/

onkeydown = function block_fkeys(event){
    var x = event.which || event.keyCode;
    if(x == 112 || x == 116){
        console.log("Blocked key");
        event.preventDefault();
        return false;
    }else{
        return;
    }
}

questions = ( typeof questions != 'undefined' && questions instanceof Array ) ? questions : [];

questions.push(
  {
    timeline: [{
      type: 'fullscreen',
      message: '<p>El experimento entrará en modo pantalla completa</p>',
      button_label: 'Full screen',
      delay_after: 0,
      fullscreen_mode: true,
      data: {procedure: 'DEMOGR'}
    }],
    conditional_function: function(){
      if(window.innerWidth != screen.width || window.innerHeight != screen.height)
        return true;
      else
        return false;
    },
    procedure: 'DEMOGR'
  }
);

DEMOGR = [];    //temporal timeline

var instruction_screen_experiment = {
    type: 'instructions',
    pages: ['<p><left><b><big>Información Sociodemográfica</big></b><br />'+
    'Las preguntas que se le realizarán a continuación son de carácter general. Le recuerdo que toda la información que usted entregue es confidencial y sólo será utilizada con fines académicos.' +'</p>'],
    data:{trialid: 'Instructions_01', procedure: 'DEMOGR'},
    show_clickable_nav: true,
    on_trial_start: function(){
        bloquear_enter = 0;
    },
    procedure: 'DEMOGR'
};

/*var question00 = {
  type: 'survey-text',
  questions: [{prompt: '<div class="justified">Rut Completo (sin puntos ni guión y con dígito verificador, en caso que termine en k, reemplace por un 0):</div>', type: 'number', range: [50000000, 500000000], required: true}],
  data: {trialid: 'DEMOGR_01'}
};
DEMOGR.push(question00);*/

var question01 = {
  type: 'survey-multi-choice-vertical',
  questions: [{prompt: '<div class="justified">Sexo:</div>', options: ['&nbsp;Hombre', '&nbsp;Mujer'], required: true, horizontal: false}],
  data: {trialid: 'DEMOGR_01', procedure: 'DEMOGR'},
  procedure: 'DEMOGR'
};
DEMOGR.push(question01);

var question02 = {
  type: 'survey-text',
  questions: [{prompt: '<div class="justified">Fecha de Nacimiento:</div>', type: 'date', required: true}],
  data: {trialid: 'DEMOGR_02', procedure: 'DEMOGR'},
  procedure: 'DEMOGR'
};
DEMOGR.push(question02);

var question03 = {
  type: 'survey-text',
  questions: [{prompt: '<div class="justified">Edad:</div>', type: 'number', required: true}],
  data: {trialid: 'DEMOGR_03', procedure: 'DEMOGR'},
  procedure: 'DEMOGR'
};
DEMOGR.push(question03);

var question04 = {
  type: 'survey-multi-choice-vertical',
  questions: [{prompt: '<div class="justified">¿Cuál es el grado más alto de educación que usted ha completado?</div>', options: ['&nbsp;Sin Estudios', '&nbsp;Básica Incompleta', '&nbsp;Básica Completa', '&nbsp;Media Incompleta', '&nbsp;Media Completa', '&nbsp;Técnica Incompleta', '&nbsp;Técnica Completa', '&nbsp;Universitaria Incompleta', '&nbsp;Universitaria Completa o más', '&nbsp;No sabe o no aplica'], required: true, horizontal: false}],
  data: {trialid: 'DEMOGR_04', procedure: 'DEMOGR'},
  procedure: 'DEMOGR'
};
DEMOGR.push(question04);

var question05 = {
  type: 'survey-text',
  questions: [{prompt: '<div class="justified">Años de estudio (considerando educación básica, media y cualquier estudio posterior):</div>', type: 'number', required: true}],
  data: {trialid: 'DEMOGR_05', procedure: 'DEMOGR'},
  procedure: 'DEMOGR'
};
DEMOGR.push(question05);

/*var question07 = {
  type: 'survey-text',
  questions: [{prompt: '<div class="justified">Comuna de Residencia:</div>', type: 'text', required: true}],
  data: {trialid: 'DEMOGR_07'}
};*/
var question06 = {
  type: 'survey-html-form',
  preamble: '<div class="justified">Elige del desplegable tu comuna de residencia.</div>', html: '<input name ="Q0" list="comunas" required><datalist id="comunas"><option value="Iquique"> <option value="Alto Hospicio"> <option value="Pozo Almonte"> <option value="Camiña"> <option value="Colchane"> <option value="Huara"> <option value="Pica"> <option value="Antofagasta"> <option value="Mejillones"> <option value="Sierra Gorda"> <option value="Taltal"> <option value="Calama"> <option value="Ollagüe"> <option value="San Pedro de Atacama"> <option value="Tocopilla"> <option value="María Elena"> <option value="Copiapó"> <option value="Caldera"> <option value="Tierra Amarilla"> <option value="Chañaral"> <option value="Diego de Almagro"> <option value="Vallenar"> <option value="Alto del Carmen"> <option value="Freirina"> <option value="Huasco"> <option value="La Serena"> <option value="Coquimbo"> <option value="Andacollo"> <option value="La Higuera"> <option value="Paiguano"> <option value="Vicuña"> <option value="Illapel"> <option value="Canela"> <option value="Los Vilos"> <option value="Salamanca"> <option value="Ovalle"> <option value="Combarbalá"> <option value="Monte Patria"> <option value="Punitaqui"> <option value="Río Hurtado"> <option value="Valparaíso"> <option value="Casablanca"> <option value="Concón"> <option value="Juan Fernández"> <option value="Puchuncaví"> <option value="Quintero"> <option value="Viña del Mar"> <option value="Isla de Pascua"> <option value="Los Andes"> <option value="Calle Larga"> <option value="Rinconada"> <option value="San Esteban"> <option value="La Ligua"> <option value="Cabildo"> <option value="Papudo"> <option value="Petorca"> <option value="Zapallar"> <option value="Quillota"> <option value="Calera"> <option value="Hijuelas"> <option value="La Cruz"> <option value="Nogales"> <option value="San Antonio"> <option value="Algarrobo"> <option value="Cartagena"> <option value="El Quisco"> <option value="El Tabo"> <option value="Santo Domingo"> <option value="San Felipe"> <option value="Catemu"> <option value="Llaillay"> <option value="Panquehue"> <option value="Putaendo"> <option value="Santa María"> <option value="Quilpué"> <option value="Limache"> <option value="Olmué"> <option value="Villa Alemana"> <option value="Rancagua"> <option value="Codegua"> <option value="Coinco"> <option value="Coltauco"> <option value="Doñihue"> <option value="Graneros"> <option value="Las Cabras"> <option value="Machalí"> <option value="Malloa"> <option value="Mostazal"> <option value="Olivar"> <option value="Peumo"> <option value="Pichidegua"> <option value="Quinta de Tilcoco"> <option value="Rengo"> <option value="Requínoa"> <option value="San Vicente"> <option value="Pichilemu"> <option value="La Estrella"> <option value="Litueche"> <option value="Marchihue"> <option value="Navidad"> <option value="Paredones"> <option value="San Fernando"> <option value="Chépica"> <option value="Chimbarongo"> <option value="Lolol"> <option value="Nancagua"> <option value="Palmilla"> <option value="Peralillo"> <option value="Placilla"> <option value="Pumanque"> <option value="Santa Cruz"> <option value="Talca"> <option value="Constitución"> <option value="Curepto"> <option value="Empedrado"> <option value="Maule"> <option value="Pelarco"> <option value="Pencahue"> <option value="Río Claro"> <option value="San Clemente"> <option value="San Rafael"> <option value="Cauquenes"> <option value="Chanco"> <option value="Pelluhue"> <option value="Curicó"> <option value="Hualañé"> <option value="Licantén"> <option value="Molina"> <option value="Rauco"> <option value="Romeral"> <option value="Sagrada Familia"> <option value="Teno"> <option value="Vichuquén"> <option value="Linares"> <option value="Colbún"> <option value="Longaví"> <option value="Parral"> <option value="Retiro"> <option value="San Javier"> <option value="Villa Alegre"> <option value="Yerbas Buenas"> <option value="Concepción"> <option value="Coronel"> <option value="Chiguayante"> <option value="Florida"> <option value="Hualqui"> <option value="Lota"> <option value="Penco"> <option value="San Pedro de la Paz"> <option value="Santa Juana"> <option value="Talcahuano"> <option value="Tomé"> <option value="Hualpén"> <option value="Lebu"> <option value="Arauco"> <option value="Cañete"> <option value="Contulmo"> <option value="Curanilahue"> <option value="Los Alamos"> <option value="Tirúa"> <option value="Los Angeles"> <option value="Antuco"> <option value="Cabrero"> <option value="Laja"> <option value="Mulchén"> <option value="Nacimiento"> <option value="Negrete"> <option value="Quilaco"> <option value="Quilleco"> <option value="San Rosendo"> <option value="Santa Bárbara"> <option value="Tucapel"> <option value="Yumbel"> <option value="Alto Biobío"> <option value="Temuco"> <option value="Carahue"> <option value="Cunco"> <option value="Curarrehue"> <option value="Freire"> <option value="Galvarino"> <option value="Gorbea"> <option value="Lautaro"> <option value="Loncoche"> <option value="Melipeuco"> <option value="Nueva Imperial"> <option value="Padre Las Casas"> <option value="Perquenco"> <option value="Pitrufquén"> <option value="Pucón"> <option value="Saavedra"> <option value="Teodoro Schmidt"> <option value="Toltén"> <option value="Vilcún"> <option value="Villarrica"> <option value="Cholchol"> <option value="Angol"> <option value="Collipulli"> <option value="Curacautín"> <option value="Ercilla"> <option value="Lonquimay"> <option value="Los Sauces"> <option value="Lumaco"> <option value="Purén"> <option value="Renaico"> <option value="Traiguén"> <option value="Victoria"> <option value="Puerto Montt"> <option value="Calbuco"> <option value="Cochamó"> <option value="Fresia"> <option value="Frutillar"> <option value="Los Muermos"> <option value="Llanquihue"> <option value="Maullín"> <option value="Puerto Varas"> <option value="Castro"> <option value="Ancud"> <option value="Chonchi"> <option value="Curaco de Vélez"> <option value="Dalcahue"> <option value="Puqueldón"> <option value="Queilén"> <option value="Quellón"> <option value="Quemchi"> <option value="Quinchao"> <option value="Osorno"> <option value="Puerto Octay"> <option value="Purranque"> <option value="Puyehue"> <option value="Río Negro"> <option value="San Juan de la Costa"> <option value="San Pablo"> <option value="Chaitén"> <option value="Futaleufú"> <option value="Hualaihué"> <option value="Palena"> <option value="Coihaique"> <option value="Lago Verde"> <option value="Aisén"> <option value="Cisnes"> <option value="Guaitecas"> <option value="Cochrane"> <option value="O Higgins"> <option value="Tortel"> <option value="Chile Chico"> <option value="Río Ibáñez"> <option value="Punta Arenas"> <option value="Laguna Blanca"> <option value="Río Verde"> <option value="San Gregorio"> <option value="Cabo de Hornos"> <option value="Antártica"> <option value="Porvenir"> <option value="Primavera"> <option value="Timaukel"> <option value="Natales"> <option value="Torres del Paine"> <option value="Santiago"> <option value="Cerrillos"> <option value="Cerro Navia"> <option value="Conchalí"> <option value="El Bosque"> <option value="Estación Central"> <option value="Huechuraba"> <option value="Independencia"> <option value="La Cisterna"> <option value="La Florida"> <option value="La Granja"> <option value="La Pintana"> <option value="La Reina"> <option value="Las Condes"> <option value="Lo Barnechea"> <option value="Lo Espejo"> <option value="Lo Prado"> <option value="Macul"> <option value="Maipú"> <option value="Ñuñoa"> <option value="Pedro Aguirre Cerda"> <option value="Peñalolén"> <option value="Providencia"> <option value="Pudahuel"> <option value="Quilicura"> <option value="Quinta Normal"> <option value="Recoleta"> <option value="Renca"> <option value="San Joaquín"> <option value="San Miguel"> <option value="San Ramón"> <option value="Vitacura"> <option value="Puente Alto"> <option value="Pirque"> <option value="San José de Maipo"> <option value="Colina"> <option value="Lampa"> <option value="Tiltil"> <option value="San Bernardo"> <option value="Buin"> <option value="Calera de Tango"> <option value="Paine"> <option value="Melipilla"> <option value="Alhué"> <option value="Curacaví"> <option value="María Pinto"> <option value="San Pedro"> <option value="Talagante"> <option value="El Monte"> <option value="Isla de Maipo"> <option value="Padre Hurtado"> <option value="Peñaflor"> <option value="Valdivia"> <option value="Corral"> <option value="Lanco"> <option value="Los Lagos"> <option value="Máfil"> <option value="Mariquina"> <option value="Paillaco"> <option value="Panguipulli"> <option value="La Unión"> <option value="Futrono"> <option value="Lago Ranco"> <option value="Río Bueno"> <option value="Arica"> <option value="Camarones"> <option value="Putre"> <option value="General Lagos"> <option value="Chillán"> <option value="Bulnes"> <option value="Chillán Viejo"> <option value="El Carmen"> <option value="Pemuco"> <option value="Pinto"> <option value="Quillón"> <option value="San Ignacio"> <option value="Yungay"> <option value="Quirihue"> <option value="Cobquecura"> <option value="Coelemu"> <option value="Ninhue"> <option value="Portezuelo"> <option value="Ranquil"> <option value="Treguaco"> <option value="San Carlos"> <option value="Coihueco"> <option value="Ñiquén"> <option value="San Fabián"> <option value="San Nicolás">  </datalist>',
  data: {trialid: 'DEMOGR_06', procedure: 'DEMOGR'},
  procedure: 'DEMOGR'
};
DEMOGR.push(question06);

var question07 = {
  type: 'survey-multi-choice-vertical',
  questions: [{prompt: '<div class="justified">Durante los últimos 12 meses ¿Ha sido diagnosticado y/o tratado por algún problema Psicológico o Psiquiátrico?</div>', options: ['&nbsp;Si', '&nbsp;No'], required: true, horizontal: false}],
  data: {trialid: 'DEMOGR_07', procedure: 'DEMOGR'},
  procedure: 'DEMOGR'
};
DEMOGR.push(question07);

var question08 = {
  type: 'survey-text',
  questions: [{prompt: '<div class="justified">¿De cuál problema fue diagnosticado y/o tratado?</div>', type: 'text', required: true}],
  data: {trialid: 'DEMOGR_07_01', procedure: 'DEMOGR'},
  procedure: 'DEMOGR'
};

var if_question08 = {
    timeline: [question08],
    conditional_function: function(){
        // get the data from the previous trial,
        // and check which key was pressed
        let data = (JSON.parse((jsPsych.data.get().values().find(x => x.trialid === 'DEMOGR_07'))["response"])["Q0"]).trim();
        if(data == "Si"){
            return true;
        } else {
            return false;
        }
    },
    procedure: 'DEMOGR'
}
DEMOGR.push(if_question08);

var question09 = {
  type: 'survey-multi-choice-vertical',
  questions: [{prompt: '<div class="justified">¿Cuál es su situación ocupacional actual?</div>', options: ['&nbsp;Trabaja a tiempo completo', '&nbsp;Trabaja a tiempo parcial', '&nbsp;Trabaja esporádicamente', '&nbsp;Está desempleado(a), pero busca trabajo', '&nbsp;Es estudiante', '&nbsp;No trabaja, ni busca trabajo', '&nbsp;Es ama de casa', '&nbsp;Está jubilado o pensionado', '&nbsp;Es rentista', '&nbsp;No sabe/No responde'], required: true, horizontal: false}],
  data: {trialid: 'DEMOGR_08', procedure: 'DEMOGR'},
  procedure: 'DEMOGR'
};
DEMOGR.push(question09);

var question10 = {
  type: 'survey-multi-choice-vertical',
  questions: [{prompt: '<div class="justified">¿Qué tipo de trabajo hace usted?</div>', options: ['&nbsp;Profesionales', '&nbsp;Ejecutivos, administrativos, gerentes', '&nbsp;Comerciantes, vendedores y cajeros', '&nbsp;Trabajos de apoyo administrativo, incluyendo trabajos eclesiásticos administrativos', '&nbsp;Trabajo con productos de precisión o artesanías. Técnicos en reparación.', '&nbsp;Operador de máquinas, instalador, inspectores', '&nbsp;Ocupaciones de transporte y manejo de carga', '&nbsp;Obreros, limpiadores de equipos, ayudantes y peones', '&nbsp;Ocupaciones de servicio, excepto empleados de casa particular', '&nbsp;Agricultor/ gerente de agricultura', '&nbsp;Campesino', '&nbsp;Fuerzas Armadas', '&nbsp;Empleados casa particular', '&nbsp;Otro'], required: true, horizontal: false}],
  data: {trialid: 'DEMOGR_08_01', procedure: 'DEMOGR'},
  procedure: 'DEMOGR'
};

var if_question10 = {
    timeline: [question10],
    conditional_function: function(){
        // get the data from the previous trial,
        // and check which key was pressed
        let data = (JSON.parse((jsPsych.data.get().values().find(x => x.trialid === 'DEMOGR_08'))["response"])["Q0"]).trim();
        if(data == "Trabaja a tiempo completo" || data == "Trabaja a tiempo parcial" || data == "Trabaja esporádicamente" ){
            return true;
        } else {
            return false;
        }
    },
    procedure: 'DEMOGR'
}
DEMOGR.push(if_question10);

var question11 = {
  type: 'survey-text',
  questions: [{prompt: '<div class="justified">Especifique el tipo de trabajo que realiza:</div>', type: 'text', required: true}],
  data: {trialid: 'DEMOGR_08_01_01', procedure: 'DEMOGR'},
  procedure: 'DEMOGR'
};

var if_question11 = {
    timeline: [question11],
    conditional_function: function(){
        // get the data from the previous trial,
        // and check which key was pressed
        let data1 = (JSON.parse((jsPsych.data.get().values().find(x => x.trialid === 'DEMOGR_08'))["response"])["Q0"]).trim();
        if(data1 == "Trabaja a tiempo completo" || data1 == "Trabaja a tiempo parcial" || data1 == "Trabaja esporádicamente" ){
            let data2 = (JSON.parse((jsPsych.data.get().values().find(x => x.trialid === 'DEMOGR_08_01'))["response"])["Q0"]).trim();
            if(data2 == "Otro" ){
                return true;
            }
          }
        return false;
    },
    procedure: 'DEMOGR'
}
DEMOGR.push(if_question11);

var question12 = {
  type: 'survey-text',
  questions: [{prompt: '<div class="justified">País de Nacimiento:</div>', type: 'text', required: true}],
  data: {trialid: 'DEMOGR_09', procedure: 'DEMOGR'},
  procedure: 'DEMOGR'
};
DEMOGR.push(question12);

DEMOGR.unshift(instruction_screen_experiment);
questions.push.apply(questions, DEMOGR)

questions.push({
    type: 'call-function',
    func: function(){
      if (online) {
        var data = jsPsych.data.get().filter({procedure: 'DEMOGR'}).csv();
      } else {
        var data = jsPsych.data.get().filter({procedure: 'DEMOGR'}).json();
      }
      saveData(data, online, 'DEMOGR');
    },
    procedure: 'DEMOGR'
});
