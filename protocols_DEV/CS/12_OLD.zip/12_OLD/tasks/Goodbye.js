/**
 * CSCN lab
/**
This document was made with test_maker
*/

onkeydown = function block_fkeys(event){
    var x = event.which || event.keyCode;
    if(x == 112 || x == 116){
        console.log("Blocked key");
        event.preventDefault();
        return false;
    }else{
        return;
    }
}

questions = ( typeof questions != 'undefined' && questions instanceof Array ) ? questions : [];

Goodbye = [];    //temporal timeline

var instruction_screen_experiment = {
    type: 'instructions',
    pages: ['<p><left><b><big>Gracias por tu participación</big></b><br />'+
    'Para terminar presiona en "Finalizar"' +'</p>'],
    data: {trialid: 'Goodbye_01', procedure: 'Goodbye'},
    button_label_next: "Finalizar",
    show_clickable_nav: true,
    on_trial_start: function(){
        bloquear_enter = 0;
    },
    procedure: 'Goodbye'
};

Goodbye.push({
  type: 'fullscreen',
  fullscreen_mode: false
});

Goodbye.unshift(instruction_screen_experiment);
questions.push.apply(questions, Goodbye);

questions.push({
    type: 'call-function',
    func: function(){
      if (online) {
        var data = jsPsych.data.get().filter({procedure: 'Goodbye'}).csv();
      } else {
        var data = jsPsych.data.get().filter({procedure: 'Goodbye'}).json();
      }
      saveData(data, online, 'Goodbye');
    },
    procedure: 'Goodbye'
});
