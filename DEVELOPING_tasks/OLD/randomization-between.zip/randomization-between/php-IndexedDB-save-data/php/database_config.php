<?php

$servername = "localhost";
$username = "username";
$password = "password";
$dbname = "database";
$table_register = "register_log";
$table_data = "data_log";
$table_conditions = "subject_log";
$port = 3306;

?>
